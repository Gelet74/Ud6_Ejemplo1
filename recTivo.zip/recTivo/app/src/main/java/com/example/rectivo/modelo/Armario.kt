package com.example.rectivo.modelo


open class Armario (
      open val codigo: String = " ",
      open val descripcion: String = " ",
      open val descripcion2: String = " ",
      open val precio: Double = 0.0,
)
class Armario40 (

) : Armario()

class Armario50 (

) : Armario()

class Armario80 (

) : Armario()

class Armario100 (

) : Armario()