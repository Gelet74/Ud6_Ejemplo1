package com.example.rectivo.conexion

interface RectivoServicioApi {


}