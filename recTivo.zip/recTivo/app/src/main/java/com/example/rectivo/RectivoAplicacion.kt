package com.example.rectivo

class RectivoAplicacion {
}