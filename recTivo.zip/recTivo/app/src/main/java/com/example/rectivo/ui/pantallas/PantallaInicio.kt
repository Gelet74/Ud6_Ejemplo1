package com.example.rectivo.ui.pantallas

class PantallaInicio {
}